package com.custom.tag;

public class TestTagCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Inside the test tag code");
	}
	
	

}
