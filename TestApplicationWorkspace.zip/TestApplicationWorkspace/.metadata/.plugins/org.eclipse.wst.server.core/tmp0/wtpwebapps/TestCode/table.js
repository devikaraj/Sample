function validate(){
	alert("Reached Javascript");
}